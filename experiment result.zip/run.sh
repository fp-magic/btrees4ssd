#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 1.0 > 16_0.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.0 -i 1.0 > 16_1.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.9 -i 0.1 > 16_2.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.8 -u 0.1 -i 0.1 > 16_3.txt

#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 32 -k 4 -v 4 -r 1.0 > t32_0.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 32 -k 4 -v 4 -r 0.0 -i 1.0 > t32_1.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 32 -k 4 -v 4 -r 0.9 -i 0.1 > t32_2.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 32 -k 4 -v 4 -r 0.8 -u 0.1 -i 0.1 > t32_3.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 64 -k 4 -v 4 -r 1.0 > t64_0.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 64 -k 4 -v 4 -r 0.0 -i 1.0 > t64_1.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 64 -k 4 -v 4 -r 0.9 -i 0.1 > t64_2.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 64 -k 4 -v 4 -r 0.8 -u 0.1 -i 0.1 > t64_3.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 128 -k 4 -v 4 -r 1.0 > t128_0.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 128 -k 4 -v 4 -r 0.0 -i 1.0 > t128_1.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 128 -k 4 -v 4 -r 0.9 -i 0.1 > t128_2.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 128 -k 4 -v 4 -r 0.8 -u 0.1 -i 0.1 > t128_3.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 256 -k 4 -v 4 -r 1.0 > t256_0.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 256 -k 4 -v 4 -r 0.0 -i 1.0 > t256_1.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 256 -k 4 -v 4 -r 0.9 -i 0.1 > t256_2.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 256 -k 4 -v 4 -r 0.8 -u 0.1 -i 0.1 > t256_3.txt

./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 1.0 > gb_0.txt
./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.0 -i 1.0 > gb_1.txt
./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.9 -i 0.1 > gb_2.txt
./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.8 -u 0.1 -i 0.1 > gb_3.txt

#./src/PiBench libbuffertree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 1.0 > nb7_0.txt
#./src/PiBench libbuffertree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.0 -i 1.0 > nb7_1.txt
#./src/PiBench libbuffertree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.9 -i 0.1 > nb7_2.txt
#./src/PiBench libbuffertree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.8 -u 0.1 -i 0.1 > nb7_3.txt

#./src/PiBench liblsmtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 1.0 > lsm_0.txt
#./src/PiBench liblsmtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.0 -i 1.0 > lsm_1.txt
#./src/PiBench liblsmtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.9 -i 0.1 > lsm_2.txt
#./src/PiBench liblsmtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.8 -u 0.1 -i 0.1 > lsm_3.txt

#./src/PiBench liblsmtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.5 -i 0.5 > lsm_4.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 1 -k 4 -v 4 -r 0.5 -i 0.5 > 4_4.txt
#./src/PiBench libbtree_wrapper.so --pcm=false -n 1000000 -p 1000000 -t 64 -k 4 -v 4 -r 0.5 -i 0.5 > t64_4.txt